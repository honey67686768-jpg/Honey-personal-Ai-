package com.honey.ai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val p = getSharedPreferences("h", 0)
        fun box(h1: String, k: String) = EditText(this).apply {
            hint = h1; setText(p.getString(k, "")); setSingleLine()
            setTextColor(0xFFF6EFDC.toInt()); setHintTextColor(0xFF85775B.toInt())
        }
        val ak = box("Anthropic API key", "ak")
        val pv = box("Picovoice AccessKey", "pv")
        val nm = box("Aap ka naam (Honey)", "name")
        val l = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(48, 110, 48, 48); setBackgroundColor(0xFF0B0905.toInt())
        }
        l.addView(TextView(this).apply { text = "Honey Personal AI"; textSize = 26f; setTextColor(0xFFF0CD6A.toInt()) })
        l.addView(TextView(this).apply { text = "\"Sweety\" bolein, woh sunegi."; setTextColor(0xFFA6967A.toInt()) })
        l.addView(ak); l.addView(pv); l.addView(nm)
        l.addView(Button(this).apply {
            text = "Shuru karein"
            setOnClickListener {
                p.edit().putString("ak", ak.text.toString().trim()).putString("pv", pv.text.toString().trim())
                    .putString("name", nm.text.toString().trim().ifEmpty { "Honey" }).apply()
                val need = arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE, Manifest.permission.READ_CONTACTS) +
                    (if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.POST_NOTIFICATIONS) else emptyArray())
                requestPermissions(need, 1)
            }
        })
        l.addView(Button(this).apply { text = "Band karein"; setOnClickListener { stopService(Intent(this@MainActivity, VoiceService::class.java)) } })
        setContentView(ScrollView(this).apply { addView(l) })
    }

    override fun onRequestPermissionsResult(rc: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(rc, perms, res)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Mic ki ijazat zaroori hai", Toast.LENGTH_LONG).show(); return
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow karke wapas aayein, phir dobara Shuru dabayein", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))); return
        }
        if (!getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName)) {
            Toast.makeText(this, "Allow karke wapas aayein, phir dobara Shuru dabayein", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))); return
        }
        startForegroundService(Intent(this, VoiceService::class.java))
        Toast.makeText(this, "Honey chalu hai. \"Sweety\" bolein!", Toast.LENGTH_LONG).show()
    }
}
