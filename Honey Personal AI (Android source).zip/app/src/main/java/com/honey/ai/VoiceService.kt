package com.honey.ai

import ai.picovoice.porcupine.PorcupineManager
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.*
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.*

class VoiceService : Service(), TextToSpeech.OnInitListener {
    private val h = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var ttsOk = false
    private var pm: PorcupineManager? = null
    private var sr: SpeechRecognizer? = null
    private var after: (() -> Unit)? = null
    private var wl: PowerManager.WakeLock? = null
    private val hist = JSONArray()
    private lateinit var p: SharedPreferences
    private val name get() = p.getString("name", "Honey") ?: "Honey"

    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, id: Int) = START_STICKY

    override fun onCreate() {
        super.onCreate()
        p = getSharedPreferences("h", 0)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("honey", "Honey", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel("open", "Honey Actions", NotificationManager.IMPORTANCE_HIGH))
        val n = Notification.Builder(this, "honey").setContentTitle("Honey sun rahi hai")
            .setContentText("\"Sweety\" bolein").setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        if (Build.VERSION.SDK_INT >= 30) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE) else startForeground(1, n)
        wl = (getSystemService(POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "honey:w").apply { acquire() }
        tts = TextToSpeech(this, this)
    }

    override fun onInit(s: Int) {
        tts?.let {
            if (it.setLanguage(Locale("ur", "PK")) < 0) it.setLanguage(Locale.US)
            it.setPitch(1.25f); it.setSpeechRate(0.95f)
            it.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(u: String?) {}
                override fun onDone(u: String?) { h.post { fin() } }
                override fun onError(u: String?) { h.post { fin() } }
            })
            ttsOk = true
        }
        startWake()
    }

    private fun say(t: String, then: (() -> Unit)? = null) {
        after = then
        if (!ttsOk) { fin(); return }
        tts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, "u")
    }
    private fun fin() { val a = after; after = null; a?.invoke() }

    /* ---- wake word (Porcupine) ---- */
    private fun startWake() {
        try {
            if (pm == null) pm = PorcupineManager.Builder().setAccessKey(p.getString("pv", "")).setKeywordPath("sweety.ppn")
                .build(this) { h.post { onWake() } }
            pm?.start()
        } catch (e: Exception) { say("Wake word shuru nahi hua. Picovoice key aur sweety.ppn check karein.") }
    }
    private fun onWake() {
        pm?.stop()
        say("جی $name، بولیے") { h.postDelayed({ listen() }, 300) }
    }

    /* ---- listen to the command ---- */
    private fun listen() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { startWake(); return }
        sr = SpeechRecognizer.createSpeechRecognizer(this)
        sr?.setRecognitionListener(object : RecognitionListener {
            override fun onResults(b: Bundle?) {
                val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                sr?.destroy(); sr = null
                if (t.isNullOrBlank()) startWake() else think(t)
            }
            override fun onError(e: Int) { sr?.destroy(); sr = null; startWake() }
            override fun onReadyForSpeech(b: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(b: Bundle?) {}
            override fun onEvent(t: Int, b: Bundle?) {}
        })
        sr?.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ur-PK"))
    }

    /* ---- Claude ---- */
    private fun think(q: String) {
        hist.put(JSONObject().put("role", "user").put("content", q))
        Thread {
            val r = try { claude() } catch (e: Exception) {
                hist.remove(hist.length() - 1)
                """{"say":"معاف کیجیے، انٹرنیٹ یا API key میں مسئلہ ہے۔","action":"none"}"""
            }
            h.post { handle(r) }
        }.start()
    }

    private fun claude(): String {
        val bi = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lvl = (bi?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0) * 100 / (bi?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100)
        val chg = bi?.getIntExtra(BatteryManager.EXTRA_STATUS, 0) == BatteryManager.BATTERY_STATUS_CHARGING
        val sys = """You are Sweety, the warm, witty, playful female voice assistant of $name. Call him "$name" like a close friend and crack light, friendly jokes when it fits. Reply ONLY with a JSON object: {"say":"<short spoken reply in Urdu script, 1-3 sentences, no emoji>","action":"none|open_app|call|youtube|whatsapp|maps|alarm","arg":"","arg2":""}. open_app: arg=app name. call: arg=contact name or number. youtube: arg=search text. whatsapp: arg=contact name or number, arg2=message text. maps: arg=place. alarm: arg=HH:MM in 24h. Phone info: battery $lvl%, charging=$chg, now=${Date()}. If the user speaks another language, reply in it."""
        val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 15000; c.readTimeout = 30000
        c.setRequestProperty("x-api-key", p.getString("ak", "")); c.setRequestProperty("anthropic-version", "2023-06-01")
        c.setRequestProperty("content-type", "application/json")
        val body = JSONObject().put("model", "claude-haiku-4-5-20251001").put("max_tokens", 400).put("system", sys).put("messages", hist)
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val txt = (if (c.responseCode < 400) c.inputStream else c.errorStream).bufferedReader().readText()
        if (c.responseCode >= 400) throw Exception(txt)
        val out = JSONObject(txt).getJSONArray("content").getJSONObject(0).getString("text")
        hist.put(JSONObject().put("role", "assistant").put("content", out))
        while (hist.length() > 20) { hist.remove(0); hist.remove(0) }
        return out
    }

    private fun handle(r: String) {
        var sp = r; var act = "none"; var a = ""; var a2 = ""
        try {
            val j = JSONObject(r.substring(r.indexOf('{'), r.lastIndexOf('}') + 1))
            sp = j.optString("say"); act = j.optString("action", "none"); a = j.optString("arg"); a2 = j.optString("arg2")
        } catch (e: Exception) {}
        try { doAct(act, a, a2) } catch (e: Exception) {}
        say(sp) { startWake() }
    }

    /* ---- actions ---- */
    private fun doAct(act: String, a: String, a2: String) {
        when (act) {
            "open_app" -> {
                val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                packageManager.queryIntentActivities(q, 0)
                    .firstOrNull { it.loadLabel(packageManager).toString().lowercase().contains(a.lowercase()) }
                    ?.let { packageManager.getLaunchIntentForPackage(it.activityInfo.packageName)?.let { i -> go(i) } }
            }
            "call" -> { val n = if (a.any { it.isDigit() }) a else lookup(a); if (n != null) go(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(n)))) }
            "youtube" -> go(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(a))))
            "whatsapp" -> {
                var n = (if (a.any { it.isDigit() }) a else lookup(a))?.filter { it.isDigit() } ?: return
                if (n.startsWith("0")) n = "92" + n.drop(1)
                go(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$n?text=" + Uri.encode(a2))))
            }
            "maps" -> go(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(a))))
            "alarm" -> {
                val t = a.split(":")
                go(Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, t[0].trim().toInt())
                    .putExtra(AlarmClock.EXTRA_MINUTES, t[1].trim().toInt()).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            }
        }
    }

    private fun lookup(n: String): String? {
        if (checkSelfPermission(android.Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?", arrayOf("%$n%"), null)?.use {
            return if (it.moveToFirst()) it.getString(0) else null
        }
        return null
    }

    /* Android blocks apps opening from the background unless "draw over other apps" is allowed; otherwise show a tap notification. */
    private fun go(i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (Settings.canDrawOverlays(this)) { try { startActivity(i) } catch (e: Exception) {} }
        else getSystemService(NotificationManager::class.java).notify(2,
            Notification.Builder(this, "open").setContentTitle("Kholne ke liye tap karein").setSmallIcon(android.R.drawable.ic_menu_send)
                .setAutoCancel(true).setContentIntent(PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)).build())
    }

    override fun onDestroy() {
        try { pm?.delete() } catch (e: Exception) {}
        sr?.destroy(); tts?.shutdown(); wl?.release()
        super.onDestroy()
    }
}
