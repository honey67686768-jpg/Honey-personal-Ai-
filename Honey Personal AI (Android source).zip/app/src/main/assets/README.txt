Yahan apni Picovoice se banayi hui 'sweety.ppn' file rakhein (naam bilkul sweety.ppn).
